from django.contrib import admin
from .models import BloodDonor
# Register your models here.

admin.site.register(BloodDonor)
