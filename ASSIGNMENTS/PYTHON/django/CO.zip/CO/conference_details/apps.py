from django.apps import AppConfig


class ConferenceDetailsConfig(AppConfig):
    name = 'conference_details'
