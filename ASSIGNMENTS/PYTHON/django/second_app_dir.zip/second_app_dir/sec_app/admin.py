from django.contrib import admin

# Register your models here.
from .models import Sec_app

admin.site.register(Sec_app)
