from django.contrib import admin
from .models import reader
# Register your models here.
admin.site.register(reader)