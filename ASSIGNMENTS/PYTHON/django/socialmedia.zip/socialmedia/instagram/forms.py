from django import forms

# class InstagramForm(forms.Form)